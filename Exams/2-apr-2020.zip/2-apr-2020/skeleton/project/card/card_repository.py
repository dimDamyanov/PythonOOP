class CardRepository:
    count = 0
    cards = []

    def add(self, card):
        if card.name in [c.name for c in self.cards]:
            raise ValueError(f'Card {card.name} already exists!')
        self.cards.append(card)
        self.count += 1

    def remove(self, card: str):
        if card == '':
            raise ValueError('Card cannot be an empty string!')
        index = None
        for ind, card_ in enumerate(self.cards):
            if card_.name == card:
                index = ind
                break

        self.cards.pop(index)

    def find(self, name: str):
        for card in self.cards:
            if card.name == name:
                return card
