class PlayerRepository:
    count = 0
    players = []

    def add(self, player):
        if player.username in [p.username for p in self.players]:
            raise ValueError(f'Player {player.username} already exists.')
        self.players.append(player)
        self.count += 1

    def remove(self, player: str):
        if player == '':
            raise ValueError('Player cannot be an empty string!')
        index = None
        for ind, player_ in enumerate(self.players):
            if player_.name == player:
                index = ind
                break

        self.players.pop(index)

    def find(self, username: str):
        for player in self.players:
            if player.username == username:
                return player
